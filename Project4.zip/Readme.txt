Rylan Casanova
04/16/23
CST-315
Project 4: File System Manager

Instructions for compiling/running Project4.cpp (File system manager)

1. Move Project4.cpp to the current directory
2. Compile Project4.cpp by executing the following command: "g++ Project4.cpp -o project4"
3. Run Project4.cpp by executing the following command: "./project4"